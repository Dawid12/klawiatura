package com.example.klawiatura;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity
{

    public TextView signView;
    public TextView messageView;
    public String[] letters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "v", "w", "x", "y", "z", "spacja"};
    public int letterIndex = 0;
    public String letter = "a";
    public String message = "";
    public long startTime = 0;
    public long endTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signView = (TextView) findViewById(R.id.sign);
        messageView = (TextView) findViewById(R.id.message);

        SensorManager sensorManager =
                (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor gyroscopeSensor =
                sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        SensorEventListener gyroscopeSensorListener = new SensorEventListener()
        {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent)
            {
                if (sensorEvent.values[2] > 3.5f)
                {
                    if (letterIndex == 0)
                    {
                        letterIndex = letters.length - 1;
                    }
                    else if (letterIndex > 0)
                    {
                        letterIndex -= 1;
                    }

                    startTime = System.currentTimeMillis();
                }
                else if (sensorEvent.values[2] < -3.5f)
                {
                    if (letterIndex == letters.length - 1)
                    {
                        letterIndex = 0;
                    }
                    else if (letterIndex < letters.length - 1)
                    {
                        letterIndex += 1;
                    }

                    startTime = System.currentTimeMillis();
                }


                letter = letters[letterIndex];
                signView.setText(letter);
                messageView.setText(message);
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i)
            {
            }

        };

        // Register the listener
        sensorManager.registerListener(gyroscopeSensorListener,
                gyroscopeSensor, SensorManager.SENSOR_DELAY_NORMAL);

        Runnable messageRunnable = new Runnable()
        {
            public void run()
            {
                endTime = System.currentTimeMillis();

                if (endTime - startTime > 2000)
                {
                    if (letterIndex == letters.length - 1)
                    {
                        message += " ";
                    }
                    else
                    {
                        message += letter;
                    }
                }
            }
        };

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(messageRunnable, 0, 2, TimeUnit.SECONDS);
    }
}

